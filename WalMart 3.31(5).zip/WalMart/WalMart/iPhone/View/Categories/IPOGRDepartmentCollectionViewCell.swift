//
//  IPOGRDepartmentCollectionViewCell.swift
//  WalMart
//
//  Created by neftali on 22/12/14.
//  Copyright (c) 2014 BCG Inc. All rights reserved.
//

import UIKit

class IPOGRDepartmentCollectionViewCell: IPODepartmentCollectionViewCell {

    override func setup() {
        super.setup()

        self.titleLabel.textColor = UIColor.blackColor()
        
    }
    
}
