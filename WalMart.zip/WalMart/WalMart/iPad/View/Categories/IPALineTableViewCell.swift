//
//  IPALineTableViewCell.swift
//  WalMart
//
//  Created by Gerardo Ramirez on 11/4/14.
//  Copyright (c) 2014 BCG Inc. All rights reserved.
//

import Foundation


class IPALineTableViewCell : IPOLineTableViewCell {
    
    override func setup() {
        super.setup()
        
        titleLabel.textColor = UIColor.whiteColor()
        
        
        
        
    }
    
    
}