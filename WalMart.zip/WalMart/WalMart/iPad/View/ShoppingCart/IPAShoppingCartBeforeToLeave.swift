//
//  IPAShoppingCartBeforeToLeave.swift
//  WalMart
//
//  Created by Gerardo Ramirez on 10/22/14.
//  Copyright (c) 2014 BCG Inc. All rights reserved.
//

import Foundation


class IPAShoppingCartBeforeToLeave : ShoppingCartCrossSellCollectionViewCell {
    
    
    override func collectionView(collectionView: UICollectionView!, layout collectionViewLayout: UICollectionViewLayout!, sizeForItemAtIndexPath indexPath: NSIndexPath!) -> CGSize {
        return CGSizeMake(170, 156)
    }

   
    
}